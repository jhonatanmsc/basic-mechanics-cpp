/*
 * prin.h
 *
 *  Created on: Jan 18, 2017
 *      Author: jhonatan
 */

#ifndef PRIN_H_
#define PRIN_H_

class prin {
public:
	prin();
	virtual ~prin();
};

#endif /* PRIN_H_ */
